# Office Space Rental Application

A React application that displays office space listings with dynamic rent pricing and modern UI design.

## Features

- **Page Heading**: Displays the application title
- **Office Space Images**: Shows images for each office space
- **Office Details**: Displays Name, Rent, and Address for each office
- **Dynamic Rent Coloring**: 
  - Red color for rent ≤ Rs. 60,000
  - Green color for rent > Rs. 60,000
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Modern UI**: Beautiful gradient background with glass-morphism effects

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Project Structure

- `src/App.js` - Main application component with office space data and rendering logic
- `src/App.css` - Styling for the application with modern design
- `src/index.js` - Application entry point
- `src/index.css` - Base styling

## Technologies Used

- React 18
- JSX
- CSS3 with modern features (Grid, Flexbox, Gradients)
- Responsive design principles

## Sample Data

The application includes 5 sample office spaces:
- DBS Tower (Chennai) - Rs. 50,000 (Red)
- Tech Park Plaza (Bangalore) - Rs. 75,000 (Green)
- Corporate Center (Hyderabad) - Rs. 45,000 (Red)
- Business Hub (Mumbai) - Rs. 85,000 (Green)
- Innovation Center (Pune) - Rs. 65,000 (Green)
