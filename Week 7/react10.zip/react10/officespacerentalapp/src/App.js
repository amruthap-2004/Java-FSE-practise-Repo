import React from 'react';
import './App.css';

function App() {
  // Create an element to display the heading of the page
  const pageHeading = "Office Space Rental Application";

  // Create a list of office objects with details
  const officeSpaces = [
    {
      id: 1,
      name: "DBS Tower",
      rent: 50000,
      address: "Chennai, Tamil Nadu",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop"
    },
    {
      id: 2,
      name: "Tech Park Plaza",
      rent: 75000,
      address: "Bangalore, Karnataka",
      image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=400&h=300&fit=crop"
    },
    {
      id: 3,
      name: "Corporate Center",
      rent: 45000,
      address: "Hyderabad, Telangana",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop"
    },
    {
      id: 4,
      name: "Business Hub",
      rent: 85000,
      address: "Mumbai, Maharashtra",
      image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=400&h=300&fit=crop"
    },
    {
      id: 5,
      name: "Innovation Center",
      rent: 65000,
      address: "Pune, Maharashtra",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop"
    }
  ];

  // Function to determine rent color based on amount
  const getRentColor = (rent) => {
    return rent <= 60000 ? 'red' : 'green';
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>{pageHeading}</h1>
      </header>
      
      <main className="office-container">
        <div className="office-grid">
          {officeSpaces.map((office) => (
            <div key={office.id} className="office-card">
              {/* Attribute to display the image of the office space */}
              <img 
                src={office.image} 
                alt={`${office.name} office space`}
                className="office-image"
              />
              
              <div className="office-details">
                {/* Display office details from object */}
                <h2>Name: {office.name}</h2>
                <h3 style={{ color: getRentColor(office.rent) }}>
                  Rent: Rs. {office.rent.toLocaleString()}
                </h3>
                <p>Address: {office.address}</p>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;
