import React, { useState } from 'react';
import './App.css';

function App() {
  const [counter, setCounter] = useState(0);
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('');

  // Function to increment counter and say hello
  const handleIncrement = () => {
    setCounter(prevCounter => prevCounter + 1);
    alert("Hello! Member1");
  };

  // Function to decrement counter
  const handleDecrement = () => {
    setCounter(prevCounter => prevCounter - 1);
  };

  // Function that takes "welcome" as argument
  const sayWelcome = (message) => {
    alert(message);
  };

  // Function to handle synthetic event OnPress
  const handleOnPress = () => {
    alert("I was clicked");
  };

  // Handle currency conversion form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!amount || !currency) {
      alert('Please fill in both amount and currency fields');
      return;
    }

    // Convert Indian Rupees to Euro (approximate rate: 1 EUR = 80 INR)
    const rupeesAmount = parseFloat(amount);
    const euroAmount = rupeesAmount / 80;
    
    alert(`Converting to ${currency} Amount is ${euroAmount.toFixed(2)}`);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Event Examples App</h1>
        
        {/* Counter Section */}
        <div className="counter-section">
          <h2>Counter: {counter}</h2>
          <div className="button-group">
            <button onClick={handleIncrement}>Increment</button>
            <button onClick={handleDecrement}>Decrement</button>
            <button onClick={() => sayWelcome("welcome")}>Say welcome</button>
            <button onClick={handleOnPress}>Click on me</button>
          </div>
        </div>

        {/* Currency Converter Component */}
        <div className="currency-converter">
          <h2 style={{ color: 'green', fontWeight: 'bold' }}>Currency Convertor!!!</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="amount">Amount:</label>
              <input
                type="number"
                id="amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount in INR"
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="currency">Currency:</label>
              <input
                type="text"
                id="currency"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                placeholder="Enter currency (e.g., Euro)"
                required
              />
            </div>
            
            <button type="submit">Submit</button>
          </form>
        </div>
      </header>
    </div>
  );
}

export default App; 