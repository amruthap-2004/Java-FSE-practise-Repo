import React from 'react';

const GuestPage: React.FC = () => {
  const flights = [
    {
      id: 1,
      airline: 'Air India',
      flightNumber: 'AI101',
      from: 'Mumbai',
      to: 'Delhi',
      departure: '10:00 AM',
      arrival: '12:00 PM',
      price: '₹5,000',
      available: true
    },
    {
      id: 2,
      airline: 'IndiGo',
      flightNumber: '6E202',
      from: 'Bangalore',
      to: 'Chennai',
      departure: '02:30 PM',
      arrival: '03:45 PM',
      price: '₹3,500',
      available: true
    },
    {
      id: 3,
      airline: 'SpiceJet',
      flightNumber: 'SG303',
      from: 'Kolkata',
      to: 'Hyderabad',
      departure: '06:15 PM',
      arrival: '08:30 PM',
      price: '₹4,200',
      available: false
    },
    {
      id: 4,
      airline: 'Vistara',
      flightNumber: 'UK404',
      from: 'Pune',
      to: 'Ahmedabad',
      departure: '09:45 AM',
      arrival: '11:00 AM',
      price: '₹3,800',
      available: true
    }
  ];

  return (
    <div className="guest-page">
      <div className="guest-header">
        <h2>Available Flights</h2>
        <p>Please login to book your tickets</p>
      </div>
      
      <div className="flights-container">
        {flights.map((flight) => (
          <div key={flight.id} className="flight-card">
            <div className="flight-header">
              <h3>{flight.airline}</h3>
              <span className="flight-number">{flight.flightNumber}</span>
            </div>
            
            <div className="flight-details">
              <div className="route">
                <div className="departure">
                  <span className="time">{flight.departure}</span>
                  <span className="city">{flight.from}</span>
                </div>
                <div className="arrow">→</div>
                <div className="arrival">
                  <span className="time">{flight.arrival}</span>
                  <span className="city">{flight.to}</span>
                </div>
              </div>
              
              <div className="flight-info">
                <span className="price">{flight.price}</span>
                <span className={`status ${flight.available ? 'available' : 'unavailable'}`}>
                  {flight.available ? 'Available' : 'Full'}
                </span>
              </div>
            </div>
            
            <div className="booking-notice">
              <p>Login required to book this flight</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GuestPage; 