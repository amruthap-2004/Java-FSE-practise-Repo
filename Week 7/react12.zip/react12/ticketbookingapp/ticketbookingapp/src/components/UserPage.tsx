import React, { useState } from 'react';

interface Flight {
  id: number;
  airline: string;
  flightNumber: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: string;
  available: boolean;
}

interface BookingForm {
  passengerName: string;
  email: string;
  phone: string;
  seats: number;
}

const UserPage: React.FC = () => {
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [bookingForm, setBookingForm] = useState<BookingForm>({
    passengerName: '',
    email: '',
    phone: '',
    seats: 1
  });
  const [bookings, setBookings] = useState<Array<{flight: Flight, booking: BookingForm}>>([]);

  const flights: Flight[] = [
    {
      id: 1,
      airline: 'Air India',
      flightNumber: 'AI101',
      from: 'Mumbai',
      to: 'Delhi',
      departure: '10:00 AM',
      arrival: '12:00 PM',
      price: '₹5,000',
      available: true
    },
    {
      id: 2,
      airline: 'IndiGo',
      flightNumber: '6E202',
      from: 'Bangalore',
      to: 'Chennai',
      departure: '02:30 PM',
      arrival: '03:45 PM',
      price: '₹3,500',
      available: true
    },
    {
      id: 3,
      airline: 'SpiceJet',
      flightNumber: 'SG303',
      from: 'Kolkata',
      to: 'Hyderabad',
      departure: '06:15 PM',
      arrival: '08:30 PM',
      price: '₹4,200',
      available: false
    },
    {
      id: 4,
      airline: 'Vistara',
      flightNumber: 'UK404',
      from: 'Pune',
      to: 'Ahmedabad',
      departure: '09:45 AM',
      arrival: '11:00 AM',
      price: '₹3,800',
      available: true
    }
  ];

  const handleBookFlight = (flight: Flight) => {
    setSelectedFlight(flight);
    setShowBookingForm(true);
  };

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setBookingForm(prev => ({
      ...prev,
      [name]: name === 'seats' ? parseInt(value) || 1 : value
    }));
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedFlight) {
      const newBooking = {
        flight: selectedFlight,
        booking: bookingForm
      };
      setBookings(prev => [...prev, newBooking]);
      setShowBookingForm(false);
      setSelectedFlight(null);
      setBookingForm({
        passengerName: '',
        email: '',
        phone: '',
        seats: 1
      });
      alert('Booking successful!');
    }
  };

  const cancelBooking = () => {
    setShowBookingForm(false);
    setSelectedFlight(null);
    setBookingForm({
      passengerName: '',
      email: '',
      phone: '',
      seats: 1
    });
  };

  return (
    <div className="user-page">
      <div className="user-header">
        <h2>Welcome back!</h2>
        <p>Book your flight tickets here</p>
      </div>

      {!showBookingForm ? (
        <>
          <div className="flights-container">
            {flights.map((flight) => (
              <div key={flight.id} className="flight-card">
                <div className="flight-header">
                  <h3>{flight.airline}</h3>
                  <span className="flight-number">{flight.flightNumber}</span>
                </div>
                
                <div className="flight-details">
                  <div className="route">
                    <div className="departure">
                      <span className="time">{flight.departure}</span>
                      <span className="city">{flight.from}</span>
                    </div>
                    <div className="arrow">→</div>
                    <div className="arrival">
                      <span className="time">{flight.arrival}</span>
                      <span className="city">{flight.to}</span>
                    </div>
                  </div>
                  
                  <div className="flight-info">
                    <span className="price">{flight.price}</span>
                    <span className={`status ${flight.available ? 'available' : 'unavailable'}`}>
                      {flight.available ? 'Available' : 'Full'}
                    </span>
                  </div>
                </div>
                
                <div className="booking-actions">
                  {flight.available ? (
                    <button 
                      onClick={() => handleBookFlight(flight)}
                      className="book-button"
                    >
                      Book Now
                    </button>
                  ) : (
                    <button className="book-button disabled" disabled>
                      Not Available
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {bookings.length > 0 && (
            <div className="bookings-section">
              <h3>Your Bookings</h3>
              <div className="bookings-list">
                {bookings.map((booking, index) => (
                  <div key={index} className="booking-card">
                    <h4>{booking.flight.airline} - {booking.flight.flightNumber}</h4>
                    <p>{booking.flight.from} → {booking.flight.to}</p>
                    <p>Passenger: {booking.booking.passengerName}</p>
                    <p>Seats: {booking.booking.seats}</p>
                    <p>Total: ₹{parseInt(booking.flight.price.replace('₹', '').replace(',', '')) * booking.booking.seats}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="booking-form-container">
          <h3>Book Flight: {selectedFlight?.airline} {selectedFlight?.flightNumber}</h3>
          <form onSubmit={handleSubmitBooking} className="booking-form">
            <div className="form-group">
              <label htmlFor="passengerName">Passenger Name:</label>
              <input
                type="text"
                id="passengerName"
                name="passengerName"
                value={bookingForm.passengerName}
                onChange={handleFormChange}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={bookingForm.email}
                onChange={handleFormChange}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="phone">Phone:</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={bookingForm.phone}
                onChange={handleFormChange}
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="seats">Number of Seats:</label>
              <input
                type="number"
                id="seats"
                name="seats"
                min="1"
                max="10"
                value={bookingForm.seats}
                onChange={handleFormChange}
                required
              />
            </div>
            
            <div className="form-actions">
              <button type="submit" className="submit-button">
                Confirm Booking
              </button>
              <button type="button" onClick={cancelBooking} className="cancel-button">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default UserPage; 