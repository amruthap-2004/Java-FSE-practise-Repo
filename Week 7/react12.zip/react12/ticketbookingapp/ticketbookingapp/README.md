# Flight Ticket Booking App

A React-based flight ticket booking application with user authentication and booking functionality.

## Features

- **Guest User Experience**: Browse available flights without the ability to book
- **Authenticated User Experience**: Full booking functionality with passenger details
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Modern UI**: Clean and intuitive user interface with smooth animations

## User Roles

### Guest Users
- View available flights
- See flight details (airline, route, timing, price)
- Cannot book tickets (login required)

### Logged-in Users
- View all available flights
- Book tickets with passenger information
- View booking history
- Manage multiple seat bookings

## Technologies Used

- React 18
- TypeScript
- CSS3 with modern styling
- Responsive design principles

## Getting Started

### Prerequisites

- Node.js (version 14 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository or navigate to the project directory
2. Install dependencies:
   ```bash
   npm install
   ```

### Running the Application

1. Start the development server:
   ```bash
   npm start
   ```

2. Open [http://localhost:3000](http://localhost:3000) to view it in the browser

### Building for Production

```bash
npm run build
```

## Project Structure

```
src/
├── components/
│   ├── LoginButton.tsx
│   ├── LogoutButton.tsx
│   ├── GuestPage.tsx
│   └── UserPage.tsx
├── App.tsx
├── App.css
├── index.tsx
└── index.css
```

## Features in Detail

### Authentication
- Simple login/logout functionality
- State management using React hooks
- Conditional rendering based on authentication status

### Flight Display
- Grid layout for flight cards
- Detailed flight information
- Availability status indicators
- Price display in Indian Rupees

### Booking System
- Passenger information form
- Seat selection (1-10 seats)
- Booking confirmation
- Booking history display

### Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Touch-friendly interface
- Optimized for all screen sizes

## Usage

1. **As a Guest**: 
   - Browse available flights
   - View flight details and prices
   - Click "Login" to access booking features

2. **As a Logged-in User**:
   - Browse flights
   - Click "Book Now" on available flights
   - Fill in passenger details
   - Confirm booking
   - View booking history

## Contributing

This is a demo application. Feel free to fork and modify for your own projects.

## License

This project is open source and available under the MIT License.
