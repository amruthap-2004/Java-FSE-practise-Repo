import React, { useState } from 'react';
import ListofPlayers from './components/ListofPlayers';
import IndianPlayers from './components/IndianPlayers';
import './App.css';

function App() {
  const [flag, setFlag] = useState(true);

  return (
    <div className="App">
      <button onClick={() => setFlag(!flag)}>
        Toggle View ({flag ? 'List of Players' : 'Indian Players'})
      </button>
      
      {flag ? (
        <div>
          <h1>List of Players</h1>
          <ListofPlayers />
          <hr />
          <h1>List of Players having Scores Less than 70</h1>
          <ListofPlayers filterBelow70={true} />
        </div>
      ) : (
        <div>
          <div>
            <h1>Indian Team</h1>
            <h1>Odd Players</h1>
            <IndianPlayers showOdd={true} />
            <hr />
            <h1>Even Players</h1>
            <IndianPlayers showEven={true} />
          </div>
          <hr />
          <div>
            <h1>List of Indian Players Merged:</h1>
            <IndianPlayers showMerged={true} />
          </div>
        </div>
      )}
    </div>
  );
}

export default App; 