import React from 'react';

const ListofPlayers = ({ filterBelow70 = false }) => {
  // Array with 11 players using ES6 array declaration
  const players = [
    { name: 'Jack', score: 50 },
    { name: 'Michael', score: 70 },
    { name: 'John', score: 40 },
    { name: 'Ann', score: 61 },
    { name: 'Elisabeth', score: 61 },
    { name: 'Sachin', score: 95 },
    { name: 'Dhoni', score: 100 },
    { name: 'Virat', score: 84 },
    { name: 'Jadeja', score: 64 },
    { name: 'Raina', score: 75 },
    { name: 'Rohit', score: 80 }
  ];

  // Filter players with scores below 70 using ES6 arrow function
  const filteredPlayers = filterBelow70 
    ? players.filter((player) => player.score <= 70)
    : players;

  return (
    <div>
      <ul>
        {filteredPlayers.map((player) => (
          <li key={player.name}>
            Mr. {player.name} <span>{player.score}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListofPlayers; 