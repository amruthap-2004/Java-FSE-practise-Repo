# Cricket App

A React application demonstrating ES6 features including array destructuring, arrow functions, map, filter, and spread operators.

## Features

### 1. ListofPlayers Component
- Array with 11 players (names and scores) using ES6 array declaration
- Uses `map()` feature to render the list
- Filters players with scores below 70 using ES6 arrow functions
- Displays "Mr. [Name] [Score]" format

### 2. IndianPlayers Component
- **OddPlayers**: Uses ES6 destructuring `[first, , third, , fifth]`
- **EvenPlayers**: Uses ES6 destructuring `[, second, , fourth, , sixth]`
- Two arrays: `T20Players` and `RanjiTrophyPlayers`
- Merges arrays using ES6 spread operator `[...T20Players, ...RanjiTrophyPlayers]`

### 3. Conditional Rendering
- Uses `flag` variable with if-else logic
- **Flag=true**: Shows List of Players and filtered players below 70
- **Flag=false**: Shows Indian Team with Odd/Even players and merged list
- Toggle button to switch between views

## ES6 Features Demonstrated
- ✅ Array destructuring
- ✅ Arrow functions
- ✅ Spread operator for array merging
- ✅ Map function for rendering lists
- ✅ Filter function for conditional display

## Installation & Usage

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm start
   ```

3. **Open browser:**
   Navigate to `http://localhost:3000`

4. **Toggle views:**
   Click the toggle button to switch between List of Players and Indian Players views

## Project Structure
```
cricketapp/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── ListofPlayers.js
│   │   └── IndianPlayers.js
│   ├── App.js
│   ├── App.css
│   └── index.js
├── package.json
└── README.md
```

## Output Examples

### When Flag=true:
- List of Players (all 11 players)
- List of Players having Scores Less than 70

### When Flag=false:
- Indian Team
- Odd Players (1st, 3rd, 5th)
- Even Players (2nd, 4th, 6th)
- List of Indian Players Merged

## Technologies Used
- React 18.2.0
- ES6+ JavaScript features
- CSS3 for styling 