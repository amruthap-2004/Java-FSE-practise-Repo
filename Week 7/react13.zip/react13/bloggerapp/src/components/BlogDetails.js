import React, { useState, useMemo, useCallback } from 'react';
import './BlogDetails.css';

const BlogDetails = () => {
  const [blogs, setBlogs] = useState([
    { 
      id: 1, 
      title: 'React Learning', 
      author: 'Stephen Biz', 
      content: 'Welcome to learning React! This comprehensive guide will take you through the fundamentals of React development.',
      category: 'tutorial',
      publishDate: '2024-01-15',
      readTime: 5,
      isPublished: true,
      likes: 45,
      featured: true
    },
    { 
      id: 2, 
      title: 'Installation', 
      author: 'Schewzdenier', 
      content: 'You can install React from npm. Follow these simple steps to get started with React development.',
      category: 'guide',
      publishDate: '2024-01-20',
      readTime: 3,
      isPublished: true,
      likes: 32,
      featured: false
    },
    { 
      id: 3, 
      title: 'Advanced Hooks', 
      author: 'React Master', 
      content: 'Deep dive into advanced React hooks like useReducer, useMemo, and useCallback for optimal performance.',
      category: 'advanced',
      publishDate: '2024-02-01',
      readTime: 8,
      isPublished: false,
      likes: 0,
      featured: false
    },
    { 
      id: 4, 
      title: 'State Management', 
      author: 'State Guru', 
      content: 'Learn about different state management solutions in React including Context API and Redux.',
      category: 'tutorial',
      publishDate: '2024-02-10',
      readTime: 10,
      isPublished: true,
      likes: 67,
      featured: true
    }
  ]);

  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date');
  const [showDrafts, setShowDrafts] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Conditional rendering using useMemo for expensive calculations
  const filteredAndSortedBlogs = useMemo(() => {
    let filtered = blogs;

    // Filter by status
    if (!showDrafts) {
      filtered = filtered.filter(blog => blog.isPublished);
    }

    // Filter by category
    if (filter !== 'all') {
      filtered = filtered.filter(blog => blog.category === filter);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(blog => 
        blog.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        blog.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        blog.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort blogs
    switch (sortBy) {
      case 'likes':
        return filtered.sort((a, b) => b.likes - a.likes);
      case 'readTime':
        return filtered.sort((a, b) => a.readTime - b.readTime);
      case 'title':
        return filtered.sort((a, b) => a.title.localeCompare(b.title));
      default:
        return filtered.sort((a, b) => new Date(b.publishDate) - new Date(a.publishDate));
    }
  }, [blogs, filter, sortBy, showDrafts, searchTerm]);

  // Conditional rendering using useCallback for event handlers
  const handleLike = useCallback((blogId) => {
    setBlogs(prevBlogs => 
      prevBlogs.map(blog => 
        blog.id === blogId 
          ? { ...blog, likes: blog.likes + 1 }
          : blog
      )
    );
  }, []);

  const handleTogglePublish = useCallback((blogId) => {
    setBlogs(prevBlogs => 
      prevBlogs.map(blog => 
        blog.id === blogId 
          ? { ...blog, isPublished: !blog.isPublished }
          : blog
      )
    );
  }, []);

  // Conditional rendering using function components
  const BlogCard = ({ blog }) => {
    // Conditional rendering using multiple ternary operators
    const getReadTimeColor = (readTime) => {
      return readTime <= 3 ? 'quick' : 
             readTime <= 7 ? 'medium' : 'long';
    };

    // Conditional rendering using logical AND
    const renderFeaturedBadge = () => {
      return blog.featured && <span className="featured-badge">Featured</span>;
    };

    // Conditional rendering using ternary operator for status
    const renderStatus = () => {
      return blog.isPublished ? 
        <span className="status published">Published</span> : 
        <span className="status draft">Draft</span>;
    };

    return (
      <div className={`blog-card ${blog.featured ? 'featured' : ''}`}>
        {renderFeaturedBadge()}
        <div className="blog-header">
          <h3>{blog.title}</h3>
          <p className="author">By {blog.author}</p>
        </div>
        
        <div className="blog-meta">
          <span className={`read-time ${getReadTimeColor(blog.readTime)}`}>
            {blog.readTime} min read
          </span>
          <span className="date">{new Date(blog.publishDate).toLocaleDateString()}</span>
          {renderStatus()}
        </div>

        <p className="content">{blog.content}</p>
        
        <div className="blog-actions">
          <button 
            className="like-btn"
            onClick={() => handleLike(blog.id)}
          >
            ❤️ {blog.likes}
          </button>
          
          {/* Conditional rendering using logical AND for admin actions */}
          {!blog.isPublished && (
            <button 
              className="publish-btn"
              onClick={() => handleTogglePublish(blog.id)}
            >
              Publish
            </button>
          )}
          
          {blog.isPublished && (
            <button 
              className="unpublish-btn"
              onClick={() => handleTogglePublish(blog.id)}
            >
              Unpublish
            </button>
          )}
        </div>
      </div>
    );
  };

  // Conditional rendering using early return for empty state
  if (blogs.length === 0) {
    return (
      <div className="blog-details">
        <h2>Blog Details</h2>
        <div className="empty-state">
          <p>No blogs available. Create your first blog post!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="blog-details">
      <h2>Blog Details</h2>
      
      <div className="controls">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search blogs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="filters">
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All Categories</option>
            <option value="tutorial">Tutorial</option>
            <option value="guide">Guide</option>
            <option value="advanced">Advanced</option>
          </select>

          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="date">Sort by Date</option>
            <option value="likes">Sort by Likes</option>
            <option value="readTime">Sort by Read Time</option>
            <option value="title">Sort by Title</option>
          </select>

          <label className="draft-toggle">
            <input
              type="checkbox"
              checked={showDrafts}
              onChange={(e) => setShowDrafts(e.target.checked)}
            />
            Show Drafts
          </label>
        </div>
      </div>

      {/* Conditional rendering using ternary operator for content */}
      {filteredAndSortedBlogs.length > 0 ? (
        <div className="blogs-container">
          <div className="blogs-grid">
            {filteredAndSortedBlogs.map(blog => (
              <BlogCard key={blog.id} blog={blog} />
            ))}
          </div>
          
          {/* Conditional rendering using logical AND for stats */}
          {filteredAndSortedBlogs.length > 1 && (
            <div className="stats">
              <p>Total Blogs: {filteredAndSortedBlogs.length}</p>
              <p>Published: {filteredAndSortedBlogs.filter(blog => blog.isPublished).length}</p>
              <p>Drafts: {filteredAndSortedBlogs.filter(blog => !blog.isPublished).length}</p>
              <p>Featured: {filteredAndSortedBlogs.filter(blog => blog.featured).length}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="no-results">
          <p>No blogs found matching your criteria.</p>
          <button onClick={() => {
            setFilter('all');
            setSearchTerm('');
            setShowDrafts(false);
          }}>
            Clear Filters
          </button>
        </div>
      )}
    </div>
  );
};

export default BlogDetails; 