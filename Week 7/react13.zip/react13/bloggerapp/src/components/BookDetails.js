import React, { useState } from 'react';
import './BookDetails.css';

const BookDetails = () => {
  const [showBooks, setShowBooks] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('name');

  // Sample book data
  const books = [
    { id: 1, name: 'Master React', price: 670, category: 'programming', rating: 4.5, inStock: true },
    { id: 2, name: 'Deep Dive into Angular 11', price: 800, category: 'programming', rating: 4.2, inStock: true },
    { id: 3, name: 'Mongo Essentials', price: 450, category: 'database', rating: 4.0, inStock: false },
    { id: 4, name: 'JavaScript Fundamentals', price: 550, category: 'programming', rating: 4.8, inStock: true },
    { id: 5, name: 'Node.js Complete Guide', price: 720, category: 'backend', rating: 4.3, inStock: true }
  ];

  // Conditional rendering using if-else (function approach)
  const renderBookStatus = (book) => {
    if (book.inStock) {
      return <span className="status in-stock">In Stock</span>;
    } else {
      return <span className="status out-of-stock">Out of Stock</span>;
    }
  };

  // Conditional rendering using switch statement
  const getCategoryColor = (category) => {
    switch (category) {
      case 'programming':
        return 'category-programming';
      case 'database':
        return 'category-database';
      case 'backend':
        return 'category-backend';
      default:
        return 'category-default';
    }
  };

  // Conditional rendering using logical AND
  const renderDiscount = (book) => {
    return book.price > 600 && <span className="discount">Save 10%</span>;
  };

  // Conditional rendering using ternary operator
  const renderRating = (rating) => {
    return rating >= 4.5 ? 
      <span className="rating high">⭐⭐⭐⭐⭐</span> : 
      rating >= 4.0 ? 
        <span className="rating medium">⭐⭐⭐⭐</span> : 
        <span className="rating low">⭐⭐⭐</span>;
  };

  // Filter books based on category
  const filteredBooks = selectedCategory === 'all' 
    ? books 
    : books.filter(book => book.category === selectedCategory);

  // Sort books
  const sortedBooks = [...filteredBooks].sort((a, b) => {
    switch (sortBy) {
      case 'price':
        return a.price - b.price;
      case 'rating':
        return b.rating - a.rating;
      default:
        return a.name.localeCompare(b.name);
    }
  });



  return (
    <div className="book-details">
      <h2>Book Details</h2>
      
      {/* Conditional rendering using logical AND */}
      {showBooks && (
        <div className="controls">
          <button onClick={() => setShowBooks(!showBooks)}>
            {showBooks ? 'Hide Books' : 'Show Books'}
          </button>
          
          <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
            <option value="all">All Categories</option>
            <option value="programming">Programming</option>
            <option value="database">Database</option>
            <option value="backend">Backend</option>
          </select>
          
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="name">Sort by Name</option>
            <option value="price">Sort by Price</option>
            <option value="rating">Sort by Rating</option>
          </select>
        </div>
      )}

      {/* Conditional rendering using ternary operator */}
      {showBooks ? (
        <div className="books-container">
          {sortedBooks.length > 0 ? (
            <div className="books-grid">
              {sortedBooks.map(book => (
                <div key={book.id} className={`book-card ${getCategoryColor(book.category)}`}>
                  <h3>{book.name}</h3>
                  <p className="price">₹{book.price}</p>
                  {renderBookStatus(book)}
                  {renderRating(book.rating)}
                  {renderDiscount(book)}
                  <span className={`category ${getCategoryColor(book.category)}`}>
                    {book.category}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="no-books">No books found in this category.</p>
          )}
        </div>
      ) : (
        <div className="hidden-message">
          <p>Books are hidden. Click "Show Books" to display them.</p>
          <button onClick={() => setShowBooks(true)}>Show Books</button>
        </div>
      )}

      {/* Conditional rendering using multiple conditions */}
      <div className="stats">
        <p>Total Books: {books.length}</p>
        <p>Books in Stock: {books.filter(book => book.inStock).length}</p>
        <p>Average Price: ₹{Math.round(books.reduce((sum, book) => sum + book.price, 0) / books.length)}</p>
      </div>
    </div>
  );
};

export default BookDetails; 