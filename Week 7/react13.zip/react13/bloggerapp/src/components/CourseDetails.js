import React, { useState, useEffect, useReducer, useRef } from 'react';
import './CourseDetails.css';

// Reducer for complex state management
const courseReducer = (state, action) => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload, isLoading: false };
    case 'SET_COURSES':
      return { ...state, courses: action.payload, isLoading: false, error: null };
    case 'TOGGLE_ENROLLMENT':
      return {
        ...state,
        courses: state.courses.map(course =>
          course.id === action.payload
            ? { ...course, isEnrolled: !course.isEnrolled }
            : course
        )
      };
    case 'UPDATE_PROGRESS':
      return {
        ...state,
        courses: state.courses.map(course =>
          course.id === action.payload.courseId
            ? { ...course, progress: action.payload.progress }
            : course
        )
      };
    default:
      return state;
  }
};

const CourseDetails = () => {
  const [state, dispatch] = useReducer(courseReducer, {
    courses: [],
    isLoading: true,
    error: null
  });

  const [viewMode, setViewMode] = useState('grid'); // grid, list, calendar
  const [filterLevel, setFilterLevel] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [searchTerm, setSearchTerm] = useState('');
  const [showCompleted, setShowCompleted] = useState(true);
  const [showEnrolled, setShowEnrolled] = useState(true);
  
  const searchRef = useRef(null);

  // Simulate API call
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        dispatch({ type: 'SET_LOADING', payload: true });
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Sample course data - moved inside useEffect to avoid dependency issues
        const sampleCourses = [
          {
            id: 1,
            name: 'Angular',
            instructor: 'John Doe',
            startDate: '2021-04-05',
            endDate: '2021-06-05',
            duration: '8 weeks',
            level: 'beginner',
            price: 299,
            rating: 4.5,
            enrolledStudents: 1250,
            maxStudents: 2000,
            isEnrolled: false,
            progress: 0,
            completed: false,
            description: 'Learn Angular from scratch with hands-on projects',
            tags: ['frontend', 'typescript', 'framework']
          },
          {
            id: 2,
            name: 'React',
            instructor: 'Jane Smith',
            startDate: '2021-06-03',
            endDate: '2021-08-03',
            duration: '10 weeks',
            level: 'intermediate',
            price: 399,
            rating: 4.8,
            enrolledStudents: 2100,
            maxStudents: 2500,
            isEnrolled: true,
            progress: 65,
            completed: false,
            description: 'Master React with hooks, context, and advanced patterns',
            tags: ['frontend', 'javascript', 'hooks']
          },
          {
            id: 3,
            name: 'Node.js Backend',
            instructor: 'Mike Johnson',
            startDate: '2021-07-15',
            endDate: '2021-09-15',
            duration: '12 weeks',
            level: 'advanced',
            price: 499,
            rating: 4.6,
            enrolledStudents: 850,
            maxStudents: 1500,
            isEnrolled: false,
            progress: 0,
            completed: false,
            description: 'Build scalable backend applications with Node.js',
            tags: ['backend', 'javascript', 'api']
          },
          {
            id: 4,
            name: 'Python for Data Science',
            instructor: 'Sarah Wilson',
            startDate: '2021-05-20',
            endDate: '2021-08-20',
            duration: '14 weeks',
            level: 'intermediate',
            price: 599,
            rating: 4.7,
            enrolledStudents: 1800,
            maxStudents: 2200,
            isEnrolled: true,
            progress: 100,
            completed: true,
            description: 'Data analysis and machine learning with Python',
            tags: ['python', 'data-science', 'ml']
          }
        ];
        
        dispatch({ type: 'SET_COURSES', payload: sampleCourses });
      } catch (error) {
        dispatch({ type: 'SET_ERROR', payload: 'Failed to fetch courses' });
      }
    };

    fetchCourses();
  }, []);

  // Conditional rendering using early return for loading state
  if (state.isLoading) {
    return (
      <div className="course-details">
        <h2>Course Details</h2>
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading courses...</p>
        </div>
      </div>
    );
  }

  // Conditional rendering using early return for error state
  if (state.error) {
    return (
      <div className="course-details">
        <h2>Course Details</h2>
        <div className="error-container">
          <p>Error: {state.error}</p>
          <button onClick={() => window.location.reload()}>
            Retry
          </button>
        </div>
      </div>
    );
  }

  // Filter and sort courses
  const filteredAndSortedCourses = state.courses
    .filter(course => {
      // Filter by level
      if (filterLevel !== 'all' && course.level !== filterLevel) return false;
      
      // Filter by completion status
      if (!showCompleted && course.completed) return false;
      
      // Filter by enrollment status
      if (!showEnrolled && course.isEnrolled) return false;
      
      // Filter by search term
      if (searchTerm && !course.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !course.instructor.toLowerCase().includes(searchTerm.toLowerCase()) &&
          !course.description.toLowerCase().includes(searchTerm.toLowerCase())) {
        return false;
      }
      
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price':
          return a.price - b.price;
        case 'rating':
          return b.rating - a.rating;
        case 'students':
          return b.enrolledStudents - a.enrolledStudents;
        case 'date':
          return new Date(a.startDate) - new Date(b.startDate);
        default:
          return a.name.localeCompare(b.name);
      }
    });

  // Conditional rendering using function components
  const CourseCard = ({ course }) => {
    const [showDetails, setShowDetails] = useState(false);

    // Conditional rendering using multiple conditions
    const getLevelColor = () => {
      switch (course.level) {
        case 'beginner': return 'level-beginner';
        case 'intermediate': return 'level-intermediate';
        case 'advanced': return 'level-advanced';
        default: return 'level-default';
      }
    };

    // Conditional rendering using ternary operator for enrollment status
    const getEnrollmentStatus = () => {
      if (course.completed) return 'completed';
      if (course.isEnrolled) return 'enrolled';
      if (course.enrolledStudents >= course.maxStudents) return 'full';
      return 'available';
    };

    // Conditional rendering using logical AND for progress bar
    const renderProgressBar = () => {
      return course.isEnrolled && (
        <div className="progress-container">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${course.progress}%` }}
            ></div>
          </div>
          <span className="progress-text">{course.progress}% Complete</span>
        </div>
      );
    };

    // Conditional rendering using switch-like object
    const getStatusIcon = () => {
      const statusIcons = {
        completed: '✅',
        enrolled: '📚',
        full: '🔒',
        available: '🎯'
      };
      return statusIcons[getEnrollmentStatus()] || '📖';
    };

    return (
      <div className={`course-card ${getLevelColor()} ${course.completed ? 'completed' : ''}`}>
        <div className="course-header">
          <h3>{course.name}</h3>
          <span className="status-icon">{getStatusIcon()}</span>
        </div>
        
        <p className="instructor">By {course.instructor}</p>
        
        <div className="course-meta">
          <span className={`level ${getLevelColor()}`}>
            {course.level}
          </span>
          <span className="duration">{course.duration}</span>
          <span className="rating">⭐ {course.rating}</span>
        </div>

        <p className="description">{course.description}</p>
        
        <div className="course-stats">
          <span className="price">₹{course.price}</span>
          <span className="students">
            {course.enrolledStudents}/{course.maxStudents} students
          </span>
        </div>

        {renderProgressBar()}

        <div className="course-tags">
          {course.tags.map(tag => (
            <span key={tag} className="tag">{tag}</span>
          ))}
        </div>

        <div className="course-actions">
          {/* Conditional rendering using multiple ternary operators */}
          {course.completed ? (
            <button className="completed-btn" disabled>
              Course Completed
            </button>
          ) : course.isEnrolled ? (
            <button 
              className="continue-btn"
              onClick={() => {
                const newProgress = Math.min(course.progress + 10, 100);
                dispatch({ 
                  type: 'UPDATE_PROGRESS', 
                  payload: { courseId: course.id, progress: newProgress }
                });
              }}
            >
              Continue Learning
            </button>
          ) : course.enrolledStudents >= course.maxStudents ? (
            <button className="full-btn" disabled>
              Course Full
            </button>
          ) : (
            <button 
              className="enroll-btn"
              onClick={() => dispatch({ 
                type: 'TOGGLE_ENROLLMENT', 
                payload: course.id 
              })}
            >
              Enroll Now
            </button>
          )}

          <button 
            className="details-btn"
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? 'Hide Details' : 'Show Details'}
          </button>
        </div>

        {/* Conditional rendering using logical AND for expandable details */}
        {showDetails && (
          <div className="course-details-expanded">
            <p><strong>Start Date:</strong> {new Date(course.startDate).toLocaleDateString()}</p>
            <p><strong>End Date:</strong> {new Date(course.endDate).toLocaleDateString()}</p>
            <p><strong>Enrolled Students:</strong> {course.enrolledStudents}</p>
            <p><strong>Max Capacity:</strong> {course.maxStudents}</p>
          </div>
        )}
      </div>
    );
  };

  // Conditional rendering using ternary operator for view mode
  const renderCourseList = () => {
    if (filteredAndSortedCourses.length === 0) {
      return (
        <div className="no-courses">
          <p>No courses found matching your criteria.</p>
          <button onClick={() => {
            setFilterLevel('all');
            setSearchTerm('');
            setShowCompleted(true);
            setShowEnrolled(true);
          }}>
            Clear Filters
          </button>
        </div>
      );
    }

    return (
      <div className={`courses-container ${viewMode}`}>
        {filteredAndSortedCourses.map(course => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    );
  };

  return (
    <div className="course-details">
      <h2>Course Details</h2>
      
      <div className="controls">
        <div className="search-section">
          <input
            ref={searchRef}
            type="text"
            placeholder="Search courses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="filters-section">
          <select value={filterLevel} onChange={(e) => setFilterLevel(e.target.value)}>
            <option value="all">All Levels</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>

          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="name">Sort by Name</option>
            <option value="price">Sort by Price</option>
            <option value="rating">Sort by Rating</option>
            <option value="students">Sort by Students</option>
            <option value="date">Sort by Date</option>
          </select>

          <div className="view-toggle">
            <button 
              className={viewMode === 'grid' ? 'active' : ''}
              onClick={() => setViewMode('grid')}
            >
              Grid
            </button>
            <button 
              className={viewMode === 'list' ? 'active' : ''}
              onClick={() => setViewMode('list')}
            >
              List
            </button>
          </div>
        </div>

        <div className="filter-toggles">
          <label>
            <input
              type="checkbox"
              checked={showCompleted}
              onChange={(e) => setShowCompleted(e.target.checked)}
            />
            Show Completed
          </label>
          <label>
            <input
              type="checkbox"
              checked={showEnrolled}
              onChange={(e) => setShowEnrolled(e.target.checked)}
            />
            Show Enrolled
          </label>
        </div>
      </div>

      {renderCourseList()}

      {/* Conditional rendering using logical AND for summary stats */}
      {filteredAndSortedCourses.length > 0 && (
        <div className="course-summary">
          <h3>Course Summary</h3>
          <div className="summary-stats">
            <div className="stat">
              <span className="stat-number">{filteredAndSortedCourses.length}</span>
              <span className="stat-label">Total Courses</span>
            </div>
            <div className="stat">
              <span className="stat-number">
                {filteredAndSortedCourses.filter(c => c.isEnrolled).length}
              </span>
              <span className="stat-label">Enrolled</span>
            </div>
            <div className="stat">
              <span className="stat-number">
                {filteredAndSortedCourses.filter(c => c.completed).length}
              </span>
              <span className="stat-label">Completed</span>
            </div>
            <div className="stat">
              <span className="stat-number">
                ₹{Math.round(filteredAndSortedCourses.reduce((sum, c) => sum + c.price, 0) / filteredAndSortedCourses.length)}
              </span>
              <span className="stat-label">Avg Price</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseDetails; 