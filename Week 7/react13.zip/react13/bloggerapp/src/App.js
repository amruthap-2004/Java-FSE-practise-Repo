import React, { useState } from 'react';
import './App.css';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';

function App() {
  const [activeTab, setActiveTab] = useState('books');
  const [showAllComponents, setShowAllComponents] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Conditional rendering using function components
  const TabButton = ({ id, label, icon }) => (
    <button
      className={`tab-button ${activeTab === id ? 'active' : ''}`}
      onClick={() => setActiveTab(id)}
    >
      {icon} {label}
    </button>
  );

  // Conditional rendering using object mapping
  const componentMap = {
    books: <BookDetails />,
    blogs: <BlogDetails />,
    courses: <CourseDetails />
  };

  // Conditional rendering using ternary operator for main content
  const renderMainContent = () => {
    if (showAllComponents) {
      return (
        <div className="all-components">
          <BookDetails />
          <BlogDetails />
          <CourseDetails />
        </div>
      );
    }
    return componentMap[activeTab];
  };

  // Conditional rendering using logical AND for theme toggle
  const renderThemeToggle = () => {
    return (
      <button 
        className="theme-toggle"
        onClick={() => setIsDarkMode(!isDarkMode)}
      >
        {isDarkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
      </button>
    );
  };

  return (
    <div className={`App ${isDarkMode ? 'dark-mode' : ''}`}>
      <header className="app-header">
        <h1>BloggerApp</h1>
        <p>A React Application Demonstrating Conditional Rendering</p>
        {renderThemeToggle()}
      </header>

      <nav className="app-navigation">
        <div className="tab-buttons">
          <TabButton id="books" label="Book Details" icon="📚" />
          <TabButton id="blogs" label="Blog Details" icon="✍️" />
          <TabButton id="courses" label="Course Details" icon="🎓" />
        </div>
        
        {/* Conditional rendering using logical AND for view toggle */}
        <div className="view-controls">
          <button 
            className={`view-toggle-btn ${showAllComponents ? 'active' : ''}`}
            onClick={() => setShowAllComponents(!showAllComponents)}
          >
            {showAllComponents ? 'Single View' : 'Show All'}
          </button>
        </div>
      </nav>

      <main className="app-main">
        {/* Conditional rendering using ternary operator for loading state */}
        {false ? (
          <div className="loading-app">
            <div className="loading-spinner"></div>
            <p>Loading BloggerApp...</p>
          </div>
        ) : (
          renderMainContent()
        )}
      </main>

      <footer className="app-footer">
        <p>
          <strong>Conditional Rendering Techniques Demonstrated:</strong>
        </p>
        <ul>
          <li>Ternary Operators (condition ? true : false)</li>
          <li>Logical AND (condition && element)</li>
          <li>Early Returns (if condition return element)</li>
          <li>Switch Statements</li>
          <li>useMemo and useCallback</li>
          <li>Function Components</li>
          <li>Object Mapping</li>
          <li>Multiple Conditions</li>
        </ul>
      </footer>
    </div>
  );
}

export default App;
