# BloggerApp - React Conditional Rendering Demo

A comprehensive React application demonstrating various conditional rendering techniques with three main components: Book Details, Blog Details, and Course Details.

## 🚀 Features

- **Three Main Components**: Book Details, Blog Details, and Course Details
- **Multiple Conditional Rendering Techniques**: 8+ different approaches
- **Interactive UI**: Filtering, sorting, searching, and real-time updates
- **Responsive Design**: Works on all device sizes
- **Dark/Light Mode**: Theme switching functionality
- **Modern UI**: Glassmorphism design with animations

## 📦 Installation

1. Clone the repository
2. Navigate to the project directory
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm start
   ```

## 🎯 Conditional Rendering Techniques Demonstrated

### 1. **Ternary Operators** (`condition ? true : false`)
```jsx
{isLoggedIn ? <UserDashboard /> : <LoginForm />}
```

### 2. **Logical AND** (`condition && element`)
```jsx
{isAdmin && <AdminPanel />}
```

### 3. **Early Returns** (if condition return element)
```jsx
if (isLoading) {
  return <LoadingSpinner />;
}
```

### 4. **Switch Statements**
```jsx
switch (userRole) {
  case 'admin': return <AdminView />;
  case 'user': return <UserView />;
  default: return <GuestView />;
}
```

### 5. **useMemo for Expensive Calculations**
```jsx
const filteredData = useMemo(() => {
  return data.filter(item => item.active);
}, [data]);
```

### 6. **useCallback for Event Handlers**
```jsx
const handleClick = useCallback(() => {
  // handler logic
}, [dependencies]);
```

### 7. **Function Components**
```jsx
const ConditionalComponent = ({ condition }) => {
  if (condition) {
    return <ComponentA />;
  }
  return <ComponentB />;
};
```

### 8. **Object Mapping**
```jsx
const componentMap = {
  books: <BookDetails />,
  blogs: <BlogDetails />,
  courses: <CourseDetails />
};
```

### 9. **Multiple Conditions**
```jsx
{status === 'loading' && <Loading />}
{status === 'error' && <Error />}
{status === 'success' && <Success />}
```

## 🏗️ Component Structure

### Book Details Component
- **Features**: Book filtering, sorting, stock status, ratings
- **Conditional Rendering**: Status badges, discount labels, category colors
- **Interactive**: Show/hide books, category filtering, price sorting

### Blog Details Component
- **Features**: Blog management, publishing status, search functionality
- **Conditional Rendering**: Featured badges, publish/unpublish buttons, draft visibility
- **Interactive**: Like functionality, search, category filtering

### Course Details Component
- **Features**: Course enrollment, progress tracking, level filtering
- **Conditional Rendering**: Enrollment status, progress bars, completion badges
- **Interactive**: Enrollment toggles, progress updates, view modes

## 🎨 UI/UX Features

- **Glassmorphism Design**: Modern glass-like effects
- **Gradient Backgrounds**: Beautiful color transitions
- **Hover Animations**: Smooth interactive feedback
- **Responsive Grid**: Adapts to different screen sizes
- **Loading States**: Spinner animations and skeleton screens
- **Error Handling**: User-friendly error messages

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- Different screen orientations

## 🛠️ Technologies Used

- **React 18**: Latest React features and hooks
- **CSS3**: Modern styling with flexbox and grid
- **JavaScript ES6+**: Modern JavaScript features
- **HTML5**: Semantic HTML structure

## 📊 Project Size

The project is optimized to be under 25MB as requested, with:
- Minimal dependencies
- Optimized images and assets
- Efficient code structure
- No unnecessary libraries

## 🚀 Getting Started

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Start Development Server**:
   ```bash
   npm start
   ```

3. **Open Browser**:
   Navigate to `http://localhost:3000`

4. **Explore Features**:
   - Switch between components using tabs
   - Try the "Show All" view to see all components
   - Toggle dark/light mode
   - Interact with filtering and sorting features

## 📝 Available Scripts

- `npm start`: Runs the app in development mode
- `npm test`: Launches the test runner
- `npm run build`: Builds the app for production
- `npm run eject`: Ejects from Create React App (one-way operation)

## 🎯 Learning Objectives

This project demonstrates:
- Various conditional rendering patterns in React
- State management with hooks
- Component composition
- Modern CSS techniques
- Responsive design principles
- Interactive UI development

## 📚 Key Concepts Covered

1. **Conditional Rendering Patterns**
2. **React Hooks** (useState, useEffect, useMemo, useCallback, useReducer)
3. **Component Architecture**
4. **Event Handling**
5. **State Management**
6. **CSS Grid and Flexbox**
7. **Responsive Design**
8. **Modern JavaScript Features**

## 🤝 Contributing

Feel free to contribute to this project by:
- Adding new conditional rendering techniques
- Improving the UI/UX
- Adding new features
- Fixing bugs
- Improving documentation

## 📄 License

This project is open source and available under the MIT License.

---

**Happy Coding! 🎉**
