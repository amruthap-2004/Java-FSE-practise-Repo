import React from 'react';

class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: [],
            loading: true,
            showCount: 3
        };
        console.log('Posts component constructor called');
    }

    loadPosts() {
        console.log('loadPosts method called');
        this.setState({ loading: true });
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(response => response.json())
            .then(data => {
                console.log('Posts loaded successfully:', data.length, 'posts');
                this.setState({ posts: data, loading: false });
            })
            .catch(error => {
                console.error('Error fetching posts:', error);
                this.setState({ loading: false });
                alert('Error loading posts: ' + error.message);
            });
    }

    componentDidMount() {
        console.log('Posts componentDidMount called');
        this.loadPosts();
    }

    showMorePosts = () => {
        this.setState(prevState => ({
            showCount: prevState.showCount + 5
        }));
    }

    render() {
        console.log('Posts render method called, posts count:', this.state.posts.length);
        const { posts, loading, showCount } = this.state;
        
        return (
            <div style={{ 
                padding: '30px', 
                backgroundColor: 'yellow', 
                margin: '30px',
                border: '5px solid red',
                borderRadius: '15px',
                fontSize: '18px',
                minHeight: '200px'
            }}>
                <h1 style={{ 
                    color: 'red', 
                    textAlign: 'center',
                    fontSize: '32px',
                    textShadow: '2px 2px 4px black'
                }}>
                    🚨 POSTS COMPONENT IS WORKING! 🚨
                </h1>
                
                {loading && (
                    <p style={{ 
                        color: 'blue', 
                        fontSize: '24px',
                        textAlign: 'center',
                        fontWeight: 'bold'
                    }}>
                        ⏳ Loading posts from API...
                    </p>
                )}
                
                {!loading && (
                    <div>
                        <h2 style={{ 
                            color: 'green', 
                            fontSize: '28px',
                            textAlign: 'center'
                        }}>
                            ✅ Total Posts Loaded: {posts.length}
                        </h2>
                        
                        {posts.slice(0, showCount).map(post => (
                            <div key={post.id} style={{ 
                                border: '3px solid blue', 
                                margin: '15px 0', 
                                padding: '15px',
                                backgroundColor: 'white',
                                borderRadius: '10px',
                                boxShadow: '0 4px 8px rgba(0,0,0,0.3)'
                            }}>
                                <h3 style={{ 
                                    color: 'purple',
                                    fontSize: '20px',
                                    marginBottom: '10px'
                                }}>
                                    Post #{post.id}: {post.title}
                                </h3>
                                <p style={{ fontSize: '16px' }}>{post.body}</p>
                            </div>
                        ))}
                        
                        {showCount < posts.length && (
                            <div style={{ textAlign: 'center', marginTop: '20px' }}>
                                <button 
                                    onClick={this.showMorePosts}
                                    style={{
                                        backgroundColor: 'blue',
                                        color: 'white',
                                        padding: '15px 30px',
                                        fontSize: '18px',
                                        border: 'none',
                                        borderRadius: '10px',
                                        cursor: 'pointer',
                                        fontWeight: 'bold'
                                    }}
                                >
                                    📄 Show More Posts ({posts.length - showCount} remaining)
                                </button>
                            </div>
                        )}
                        
                        {showCount >= posts.length && (
                            <p style={{ 
                                color: 'green', 
                                fontSize: '20px',
                                textAlign: 'center',
                                fontWeight: 'bold'
                            }}>
                                🎉 All posts displayed!
                            </p>
                        )}
                    </div>
                )}
            </div>
        );
    }

    componentDidCatch(error, info) {
        alert('Error in Posts component: ' + error.message);
        console.error('Error details:', error, info);
    }
}

export default Posts; 