# Cohort Dashboard

A React application that displays details of ongoing and completed cohorts for the Academy team at Cognizant.

## Features

- Displays cohort information in styled cards
- Shows cohort status with color-coded titles (green for ongoing, blue for others)
- Responsive design with CSS modules
- Clean and modern UI

## Cohort Information Displayed

- Cohort ID and Name
- Start Date
- Current Status
- Coach Name
- Trainer Name

## Styling

The application uses CSS modules with the following styling:
- Box layout with 300px width
- Inline-block display
- 10px margin
- 10px top/bottom padding, 20px left/right padding
- 1px black border with 10px border radius
- Font weight 500 for definition terms

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm start
   ```

3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Project Structure

- `src/CohortDetails.js` - Main component displaying cohort information
- `src/CohortDetails.module.css` - CSS module for styling
- `src/App.js` - Main application component
