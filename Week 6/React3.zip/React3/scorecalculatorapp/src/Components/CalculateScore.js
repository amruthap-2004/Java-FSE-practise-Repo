import React from 'react';
import '../Stylesheets/mystyle.css'

const percentToDecimal = (decimal) => {
  return (decimal.toFixed(2) + '%')
}

const calcScore = (total, goal) => {
  return percentToDecimal(total/goal)
}

const CalculateScore = ({ Name, School, total, goal }) => {
  const score = calcScore(total, goal);
  
  return (
    <div className="formatstyle">
      <h1 className="Name">{Name}</h1>
      <h2 className="School">{School}</h2>
      <h3 className="Total">Total: {total}</h3>
      <h3 className="Score">Score: {score}</h3>
    </div>
  );
}

export default CalculateScore;