This is the cleanup lab readme
